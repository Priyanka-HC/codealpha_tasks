**\*\*Task 3: Data Visualization\*\***







**\*\*Objective\*\***



The objective of this task is to transform raw data into meaningful visual representations to better understand patterns, trends, and insights, and to support data-driven decision-making.







**\*\*Dataset\*\***



Source: Generated from Task 1 (Web Scraping)



File Name: books\_data.xlsx



Features:



\&#x20; - Title (Book Name)



\&#x20; - Price (Book Price)







**\*\*Tools \& Technologies Used\*\***



\\- Python



\\- Pandas



\\- Matplotlib







**\*\*Methodology\*\***



1\\. Loaded and cleaned the dataset using Pandas.



2\\. Converted price values into numeric format.



3\\. Categorized book prices into Low, Medium, and High ranges.



4\\. Created multiple visualizations to analyze patterns and trends.



5\\. Used different types of graphs for better understanding of data.







**\*\*Visualizations Created\*\***



Box Plot:



\&#x20; - Displays distribution and identifies outliers in book prices



Pie Chart:



\&#x20; - Shows proportion of books in different price categories (Low, Medium, High)



Line Plot:



\&#x20; - Represents trend of book prices across dataset



Scatter Plot:



\&#x20; - Shows relationship between book index and price



Bar Chart:



\&#x20; - Highlights top 10 most expensive books







**\*\*Insights\*\***



\\- Most books fall within the medium price range



\\- A few books have very high prices (outliers)



\\- Price distribution varies across dataset



\\- Expensive books are clearly visible in bar chart



\\- Trends can be observed using line and scatter plots







**\*\*Data Representation Benefits\*\***



\\- Visualizations simplify complex data



\\- Helps in quick understanding of patterns



\\- Improves data storytelling



\\- Supports better decision-making







**\*\*Result\*\***



Successfully transformed raw data into meaningful visual insights using multiple graphs and charts.







**\*\*Conclusion\*\***



Data visualization helped in understanding pricing patterns clearly and effectively. The visual insights make the dataset easier to interpret and useful for further analysis.

