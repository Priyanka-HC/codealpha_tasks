import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_excel("books_data.xlsx")

df.columns = df.iloc[0]
df = df[1:]
df.columns = ["Title", "Price"]

df["Price"] = df["Price"].str.replace("Â£", "")
df["Price"] = df["Price"].astype(float)

# 1. Box Plot
plt.figure()
plt.boxplot(df["Price"])
plt.title("Price Distribution (Box Plot)")
plt.ylabel("Price")
plt.show()

# 2. Pie Chart
def categorize(price):
    if price < 20:
        return "Low"
    elif price < 40:
        return "Medium"
    else:
        return "High"
df["Category"] = df["Price"].apply(categorize)
category_counts = df["Category"].value_counts()
plt.figure()
plt.pie(category_counts, labels=category_counts.index, autopct='%1.1f%%')
plt.title("Book Price Categories")
plt.show()

# 3. Line Plot
plt.figure()
plt.plot(df["Price"])
plt.title("Price Trend Across Books")
plt.xlabel("Book Index")
plt.ylabel("Price")
plt.show()

# 4. Scatter Plot
plt.figure()
plt.scatter(range(len(df)), df["Price"])
plt.title("Price Scatter Plot")
plt.xlabel("Book Index")
plt.ylabel("Price")
plt.show()

# 5. Bar Chart (Top 10 Books)
top10 = df.sort_values(by="Price", ascending=False).head(10)
plt.figure()
plt.barh(top10["Title"], top10["Price"])
plt.title("Top 10 Expensive Books")
plt.xlabel("Price")
plt.ylabel("Book Title")
plt.show()