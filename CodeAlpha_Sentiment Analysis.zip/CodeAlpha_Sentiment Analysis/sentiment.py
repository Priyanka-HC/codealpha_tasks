import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt

df = pd.read_excel("Reviews.xlsx")

def get_sentiment(text):
    polarity = TextBlob(text).sentiment.polarity

    if polarity > 0.1:
        return "Positive"
    elif polarity < -0.1:
        return "Negative"
    else:
        return "Neutral"

df["Sentiment"] = df["Review"].apply(get_sentiment)

print("\nSentiment Analysis Results:\n")
print(df)

counts = df["Sentiment"].value_counts()
print("\nSentiment Count:\n")
print(counts)

plt.figure()
counts.plot(kind="bar")
plt.title("Sentiment Distribution")
plt.xlabel("Sentiment")
plt.ylabel("Count")
plt.show()