import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_excel("books_data.xlsx")

df.columns = df.iloc[0]
df = df[1:]
df.columns = ["Title", "Price"]

df["Price"] = df["Price"].str.replace("Â£", "")
df["Price"] = df["Price"].astype(float)

print("First 5 rows:")
print(df.head())

print("\nDataset Info:")
print(df.info())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nStatistical Summary:")
print(df.describe())

print("\nAverage Price:", df["Price"].mean())

top_books = df.sort_values(by="Price", ascending=False).head(5)
print("\nTop 5 Expensive Books:")
print(top_books)

plt.figure()
plt.hist(df["Price"], bins=10)
plt.title("Price Distribution")
plt.xlabel("Price")
plt.ylabel("Number of Books")
plt.show()

plt.figure()
plt.barh(top_books["Title"], top_books["Price"])
plt.title("Top 5 Expensive Books")
plt.xlabel("Price")
plt.ylabel("Book Title")
plt.show()