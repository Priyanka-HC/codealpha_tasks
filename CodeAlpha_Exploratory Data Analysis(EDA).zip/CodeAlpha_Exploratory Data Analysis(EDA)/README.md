**Task 2: Exploratory Data Analysis (EDA)**



**Objective**

The objective of this task is to analyze the dataset, understand its structure, identify patterns, and extract meaningful insights using statistical methods and visualization techniques.



**Dataset**

Source: Generated from Task 1 (Web Scraping)

File Name: books\_data.xlsx

Features:

&#x20; - Title (Book Name)

&#x20; - Price (Book Price)



**Tools \& Technologies Used**

\- Python

\- Pandas

\- Matplotlib



**Methodology**

1\. Loaded the dataset using Pandas.

2\. Cleaned the dataset:

&#x20;  - Removed unwanted characters (Â£) from price column

&#x20;  - Converted price values to numeric format

&#x20;  - Corrected column names

3\. Explored dataset structure using:

&#x20;  - `head()` for preview

&#x20;  - `info()` for data types

4\. Checked for missing values.

5\. Generated statistical summary using `describe()`.



**Questions Considered**

\- What is the average price of books?

\- Which books are the most expensive?

\- How are book prices distributed?

\- Are there any anomalies in pricing?



**Analysis \& Insights**

\- Average book price is approximately \*\*£38.04\*\*

\- Prices range from \*\*£13.99 to £57.25\*\*

\- Most books fall within a moderate price range

\- Identified top 5 expensive books using sorting



**Visualization**

Histogram:

&#x20; - Displays distribution of book prices

Bar Chart:

&#x20; - Shows top 5 most expensive books



**Data Issues \& Fixes**

Encoding issue detected (`Â£` instead of `£`)

Incorrect column headers

Price stored as text instead of numeric



**Fixes Applied**

\- Cleaned special characters

\- Converted data types

\- Structured dataset properly



**Result**

Successfully performed Exploratory Data Analysis by:

\- Cleaning and structuring the dataset

\- Identifying patterns and trends

\- Generating meaningful insights

\- Visualizing data using graphs



**Conclusion**

EDA helped in understanding the dataset and uncovering insights about book pricing. The cleaned and analyzed data is now ready for further visualization and advanced analysis.

