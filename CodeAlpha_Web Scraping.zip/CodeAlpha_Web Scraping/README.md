**CodeAlpha Data Analytics Internship Project**



**Task 1: Web Scraping**



**Objective**

The objective of this task is to extract useful data from a public website using Python and convert it into a structured dataset for analysis.



**Data Source**

Website used for scraping:

http://books.toscrape.com/

This is a publicly available website designed for practicing web scraping.



**Tools \& Technologies Used**

\- Python

\- Requests (for sending HTTP requests)

\- BeautifulSoup (for parsing HTML content)

\- Pandas (for data manipulation and storage)



**Methodology**

1\. Sent an HTTP request to the target website using the Requests library.

2\. Parsed the HTML content using BeautifulSoup.

3\. Identified relevant HTML tags containing required data.

4\. Extracted:

&#x20;  - Book Titles

&#x20;  - Book Prices

5\. Stored extracted data in Python lists.

6\. Converted data into a structured format using Pandas DataFrame.

7\. Exported the dataset into a CSV file.



**Output**

Generated file: `books\_data.csv`

Dataset includes:

&#x20; - Title of the book

&#x20; - Price of the book



**Result**

Successfully performed web scraping and created a structured dataset from raw web data.  

This dataset can be used for further data analysis and visualization.



**Learning Outcomes**

\- Understanding of web scraping concepts.

\- Handling HTML structure and tags.

\- Data extraction using BeautifulSoup.

\- Converting raw data into structured format.

\- Saving datasets for further analysis.



**Conclusion**

This task demonstrates the ability to collect real-world data from websites and prepare it for analysis. It forms the foundation for advanced data analytics tasks such as EDA and visualization.

